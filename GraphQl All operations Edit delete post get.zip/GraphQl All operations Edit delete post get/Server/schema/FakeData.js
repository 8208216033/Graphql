const UserList = [
  {
    id: 1,
    name: "John",
    username: "john",
    age: 20,
    nationality: "Canada",
    friends:[
      {
        id: 2,
        name: "Johnny",
        username: "johnny",
        age: 30,
        nationality: "Brazil",
      },
      {
        id: 5,
        name: "Ram",
        username: "Ram",
        age: 34,
        nationality: "India",
      },
    ]
  },
  {
    id: 2,
    name: "Johnny",
    username: "johnny",
    age: 30,
    nationality: "Brazil",
  },
  {
    id: 3,
    name: "Jooly",
    username: "jooly",
    age: 10,
    nationality: "Canada",
  },
  {
    id: 4,
    name: "Sara",
    username: "Sara",
    age: 50,
    nationality: "US",
  },
  {
    id: 5,
    name: "Ram",
    username: "Ram",
    age: 34,
    nationality: "India",
  },
];

const MovieList=[
  {
    id:1,
    name:"DDLJ",
    yearOfPublication:1999,
    isInTheaters:true

  },
  {
    id:2,
    name:"KKKG",
    yearOfPublication:2000,
    isInTheaters:true

  },
  {
    id:3,
    name:"DEVDAS",
    yearOfPublication:1996,
    isInTheaters:true

  }
]

module.exports = { UserList,MovieList};
