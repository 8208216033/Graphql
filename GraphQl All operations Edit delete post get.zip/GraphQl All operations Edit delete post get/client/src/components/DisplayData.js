import React, { useState } from "react";
import { useQuery, gql, useLazyQuery, useMutation } from "@apollo/client";
import "../App.css";
//for fetching users
const QUERY_ALL_USERS = gql`
  query getallUsers {
    users {
      id
      name
      username
      age
      nationality
    }
  }
`;
const QUERY_ALL_MOVIES = gql`
  query getallMovies {
    movies {
      id
      name
      yearOfPublication
      isInTheaters
    }
  }
`;

const GET_MOVIE_BY_NAME = gql`
  query Movie($name: String!) {
    movie(name: $name) {
      name
      yearOfPublication
    }
  }
`;
const CREATE_USER_MUTATION = gql`
  mutation CreateUser($input: CreateUserInput!) {
    createUser(input: $input) {
      id
    }
  }
`;

const DELETE_USER_MUTATION = gql`
  mutation DeleteUser($deleteUserId: ID!) {
    deleteUser(id: $deleteUserId) {
      id
    }
  }
`;

const UPDATE_USER_MUTATION = gql`
  mutation updateUserName($input: updateUserInput) {
    updateUsername(input: $input) {
      id
      username
    }
  }
`;



const DisplayData = () => {
  const { data, loading, error, refetch } = useQuery(QUERY_ALL_USERS);
  const {
    data: movieData,
    loading: movieLoading,
    error: movieError,
  } = useQuery(QUERY_ALL_MOVIES);
  const [movieSearched, setMovieSearched] = useState("");
  const [fetchMovie, { data: movieSearchedData, error: movieErrors }] =
    useLazyQuery(GET_MOVIE_BY_NAME);

  //create an user
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [age, setAge] = useState("");
  const [nationality, setNationality] = useState("");
  const [createUser] = useMutation(CREATE_USER_MUTATION);

  //delete user
  const [deleteUser] = useMutation(DELETE_USER_MUTATION, {
    onCompleted: () => refetch(),
  });
  const DeleteUser = (id) => {
    console.log("id...", id);
    deleteUser({
      variables: {
        deleteUserId: id,
      },
    });
  };
  //update username
  const [updateUsername] = useMutation(UPDATE_USER_MUTATION, {
    onCompleted: () => refetch(),
  });
  const UpdateUser=(id,username)=>
  {
    updateUsername({
      variables:{
        updateUserId:id,
        username: username
        
      }
    });
    refetch()
  }
  return (
    <>
      <div>
        <input
          type="text"
          placeholder="name"
          onChange={(event) => {
            setName(event.target.value);
          }}
        />
        <br />
        <input
          type="text"
          placeholder="username"
          onChange={(event) => {
            setUsername(event.target.value);
          }}
        />
        <br />
        <input
          type="number"
          placeholder="age"
          onChange={(event) => {
            setAge(event.target.value);
          }}
        />
        <br />
        <input
          type="text"
          placeholder="nationality"
          onChange={(event) => {
            setNationality(event.target.value);
          }}
        />
        <br />
        <button
          onClick={() => {
            createUser({
              variables: {
                input: {
                  name: name,
                  username: username,
                  age: Number(age),
                  nationality: nationality,
                },
              },
            });
            refetch();
          }}
        >
          Create user
        </button>
      </div>
      <div>DisplayData</div>
      <table>
        <thead>
          <tr>
            <th>id</th>
            <th>name</th>
            <th>username</th>
            <th>age</th>
            <th>nationality</th>
            <th>Actions</th>
          </tr>
        </thead>
        {data &&
          data.users.map((user) => {
            return (
              <>
                <tbody>
                  <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>{user.name}</td>
                    <td>{user.username}</td>
                    <td>{user.age}</td>
                    <td>{user.nationality}</td>
                    <td>
                      <button onClick={() => DeleteUser(user.id)}>
                        Delete User
                      </button>
                      <button onClick={() => UpdateUser(user.id,user.username)}>
                        Update User
                      </button>
                    </td>
                  </tr>
                </tbody>
              </>
            );
          })}
      </table>
      <h1>Movie List</h1>
      <table>
        <thead>
          <tr>
            <th>id</th>
            <th>name</th>
            <th>Year Of Publication</th>
          </tr>
        </thead>

        {movieData &&
          movieData.movies.map((movie) => {
            return (
              <>
                <tbody>
                  <tr key={movie.id}>
                    <td>{movie.id}</td>
                    <td>{movie.name}</td>
                    <td>{movie.yearOfPublication}</td>
                  </tr>
                </tbody>
              </>
            );
          })}
      </table>

      {/* update user */}
      <div>
      <input
          type="text"
          placeholder="name"
         value={name}
        />
        <br />
        <input
          type="text"
          placeholder="username"
          onChange={(event) => {
            setUsername(event.target.value);
          }}
        />
        <br />
        <input
          type="number"
          placeholder="age"
          value={age}
         
        />
        <br />
        <input
          type="text"
          placeholder="nationality"
         value={nationality}
        />
        <br />
        <button
          onClick={() => {
            UpdateUser()
          }}
        >
          Update user
        </button>
      </div>
    </>
  );
};

export default DisplayData;
