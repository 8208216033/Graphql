import logo from './logo.svg';
import { useQuery,gql  } from '@apollo/client';
import './App.css';
import CharacterList from './Pages/CharacterList';
import {Routes,Route} from 'react-router'
import Character from './Pages/Character';
import Search from './Pages/Search';
function App() {
  
  return (
    <div className="App">
     <Routes>
      <Route exact path='/' element={ <CharacterList/>}/>
      <Route exact path='/search' element={<Search/>}/>
      <Route exact path='/:id' element={<Character/>}/>
      
     </Routes>
      
    </div>
  );
}

export default App;
