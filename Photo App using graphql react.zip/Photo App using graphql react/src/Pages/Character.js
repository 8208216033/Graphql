import React from 'react'
import {useSingleCharacter} from '../Hooks/useSingleCharacter'
import './Character.css'
import {useParams} from 'react-router'
const Character = () => {
    const {id}=useParams()
    const {data,loading,error}=useSingleCharacter(id);
  console.log({error,loading,data})
  if(error) return <div><h1>Somthing went wrong</h1></div> 
  if(loading) return <div><h1>Please wait</h1></div>
  return (
    <div className='character'>
        <img src={data.character.image} width={750} height={750}/>
        <div className='character-content'>
            <h1>{data.character.name}</h1>
            <p>{data.character.gender}</p>
            <div className='character-episode'>
                {
                    data.character.episode.map(episode=>
                        {
                            return <div>
                                {episode.name}=<b>{episode.episode}</b>
                                </div>
                        })
                }
            </div>
        </div>
    </div>
  )
}

export default Character