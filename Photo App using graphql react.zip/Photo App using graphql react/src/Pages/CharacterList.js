import React from 'react'
import {Link} from 'react-router-dom'
import { useQuery,gql  } from '@apollo/client';
import './CharacterList.css'
import useCharacter from '../Hooks/useCharacter';
// const GET_CHARACTERS=gql `
// query {
//   characters {
//     results {
//       id
//       name
//       image

//     }
//   }
// }
// `
const CharacterList = () => {
    // const {error,data,loading}=useQuery(
    //     GET_CHARACTERS
    //   );
   const {error,loading,data}=useCharacter();
      console.log({error,loading,data})
    if(loading)  return <div><h1>Please wait...</h1></div>
    if (error) return <div>Something is wrong..</div>
    return (
    <div className='characterList'>
        {data.characters.results.map(character=>
            {
                return <div>
                   <Link to={`/${character.id}`}>
                   <img src={character.image}/>
                    <h2>{character.name}</h2>
                   </Link>
                    </div>
            })}
    </div>
  )
}

export default CharacterList