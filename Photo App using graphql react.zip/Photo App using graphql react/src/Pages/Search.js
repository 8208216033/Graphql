import React,  { useState } from 'react'
import {gql,useLazyQuery} from '@apollo/client'
const GET_CHARCTER_LOCATIONS=gql`
query Get{
   characters(filter:{
    name:$name
   }) 
   {
    results{
        location{
            name
        }
    }
   }
}
`
const Search = () => {
    const [name,setName]=useState("");
     const [getLocations,{loading,error,data,called}]=useLazyQuery(GET_CHARCTER_LOCATIONS,{
        variables:{
            name,
        }
     })

     console.log({called,error,loading,data})
  return (
    <div>

        <input value={name} onChange={(e)=>setName(e.target.value)}/>
        <button onClick={()=>getLocations()}>Search</button>
    </div>
  )
}

export default Search